# 🌺 Website Bunga Bangkai

Project website sederhana bertema bunga bangkai (Amorphophallus titanum).

## Fitur
- Tema gelap sesuai karakter bunga
- Desain sederhana
- Mudah di-deploy ke GitHub Pages

## Cara Menjalankan
1. Download / clone repo
2. Buka file index.html di browser

## Author
Sai Nameless
